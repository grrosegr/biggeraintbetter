Super Mario World complete background rip by Ultramario.

Use the file "BGcolor" to pick background color for the backgrounds.

If you want to give credit, give it to Nintendo.